var me = document.getElementById('me');
var rock = document.getElementById('rock');

function jump() {
    
    if (me.classList != "animat") {
        me.classList.add("animat");
        
    }

    setTimeout(() => {
        me.classList.remove("animat");
    },700)
}

setInterval(() => {
    var meTop =
    parseInt(window.getComputedStyle(me).getPropertyValue('top'));
    var rockleft =
    parseInt(window.getComputedStyle(rock).getPropertyValue('left'));
   
    if(rockleft < 20 && rockleft > 0 && meTop >= 280)
    {
        rock.style.animation = 'none';
        rock.style.display = 'none';
        alert (' Game over ');
    }
}, 10);