var btn = document.querySelector('#btn');
var hex = document.querySelector('.hex');
var body = document.querySelector('body');


var lett = ['0' , '2' , '3' ,'4' , '5' , '6' , '7' , '8' , '9' , 'a' , 'b' , 'c' , 'd' ,'f'];
var arr = [];

btn.addEventListener('click', () => {
for(let i=0 ; i<3 ; i++){
    arr.push(lett[Math.floor(Math.random() * 6)]
    + lett[Math.floor(Math.random() * 6)]);
}

let code ;
code = '#' + arr[0] + arr[1]  + arr[2];
hex.innerHTML = code;
body.style.backgroundColor = code;
arr = [];
});