const file_upload_input = document.getElementById('file-upload-input');
file_upload_input.addEventListener('change' ,()=>{

    let file_path = file_upload_input.value;
    let fileName = file_path.split('\\');
    let index = fileName.length - 1;
    const file_name = document.querySelector('.file-upload__file-name');
    file_name.innerText = fileName[index];

});
  

